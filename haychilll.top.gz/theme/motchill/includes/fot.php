<div id="footer">
    <div class="container">
        <div class="desc">
            <p>
                <a href="/"><b style="color: yellow;">MotChill</b></a> là website Xem phim nhanh, phim hd vietsub chất lượng cao miễn phí. Xem phim hd VietSub. Phim thuyết minh chất lượng HD. Kho phim chuẩn nhanh online hay hấp dẫn.
            </p>
                 <p style="text-align: center;font-size: 13px;color: #ffff;">Copyright 2023 © <a href="/" title="//MotChillz.top">MotChill</a></p>
             <p style="text-align: center;font-size: 13px;color: #ffff;">                
                 Liên hệ lên hệ quảng cáo | Telegram: <strong>@ssplaynet</strong>
                </p>
        </div>        
        <div class="info">
            <!--contact-->
            <div class="column">
                <div class="heading">Quy định</div>
                <ul>
                    <li>
                        <a href="#">Điều khoản chung</a>
                    </li>
                    <li>
                        <a href="#">Chính sách riêng tư</a>
                    </li>
                </ul>
            </div>
            <div class="column">
                <div class="heading">Giới thiệu</div>
                <ul>
                    <li>
                        <a href="#">Trang chủ</a>
                    </li>
                    <li>
                        <a href="#">Facebook</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=zzzzzzzzzzz"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'zzzzzzzz');
</script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/phantom0803/ophim-theme-motchill@main/resources/assets/js/owl.carousel.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#film_hot").owlCarousel({
                items: 5,
                itemsTablet: [700, 3],
                itemsMobile: [479, 2],
                scrollPerPage: true,
                lazyLoad: true,
                navigation: true, // Show next and prev buttons
                slideSpeed: 800,
                paginationSpeed: 400,
                stopOnHover: true,
                pagination: false,
                autoPlay: 8000,
                navigationText: ['<i class="fa fa-angle-left"></i>', ' <i class="fa fa-angle-right"></i>'],
            });
        });
    </script>
<script>
   $(document).ready(function(){
      $("#film_related").owlCarousel({
         items:4,
         itemsTablet: [700,3],
         itemsMobile : [479,2],
         navigation : true, // Show next and prev buttons
         slideSpeed : 300,
         paginationSpeed : 400,
         stopOnHover:true,
         pagination:false,
         navigationText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>']
      });
   })
</script>
    <script>
        $(document).ready(function() {
            $("img.lazy").lazyload({
                effect: "fadeIn"
            });
        });
    </script>
  
<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/phantom0803/ophim-theme-motchill@main/resources/assets/js/jquery.lazyload.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/phantom0803/ophim-theme-motchill@main/resources/assets/js/bootstrap2.min.js"></script> 
</body>
</html>
