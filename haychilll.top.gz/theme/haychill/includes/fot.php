    <div id="footer">
        <div class="block1">
            <div class="container">
                <p><a href="https://haychilll.top"><b>HAYCHILLL</b></a> giúp bạn xem nhiều phim thuyết minh, phim lồng tiếng nhanh nhất, giao diện dễ sử dụng, cộng đồng phim cùng haychill lớn mạnh</p>
            </div>
        </div>
        <div class="block1">
            <div class="container">
                <div class="col1">
                    <p class="title">HayChilll.top</p>
                    <ul> Telegram: @haychill </ul>
                </div>
                <div class="col5">
                    <div class="sitemap"> <a href="/sitemap.xml" title="Sitemap" class="style2">Sitemap</a> | <a href="/phim-moi" title="Phim mới" class="style2">Phim mới</a> </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-zzzzzz"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'G-zzzzz');
</script>
<script type="text/javascript">Phim3s.Home.init();</script>
<script type="text/javascript" src="/css/other.js?12"></script>