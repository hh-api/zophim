<?php
include 'databases.php';
include 'theme/'.$theme.'/index.php';
?>