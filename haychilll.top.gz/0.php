<?php
include 'databases.php';
$run = mysqli_query($apizophim, "UPDATE phim SET view_day='0'");
?>